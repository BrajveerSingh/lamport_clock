To start the client

java -jar lamportclockclient.jar

NOTE: See the screenshots for reference