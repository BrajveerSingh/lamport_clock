To start the server:

java -jar lamportclockserver.jar

NOTE: See the screenshot running_server.png for reference